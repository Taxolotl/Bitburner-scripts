Guide to my scripts:

  buy-server.js is the script you run when you want to buy a server.

  crimes.js is a WIP, I need BN4;

  find-coding-contract is a script that looks for coding contracts and tells you the closest one.

  find-server.js finds a specific folder that you give it via args.

  factions-toast.js makes a toast pop up whenever you can join a faction. it also tells you what you need to do for it. BN4 will improve

  getPlayer.js makes a menu show up with all of your information

  go.js is the main money-earning script.
    deploys wk.js, hk.js, and gr.js to all servers with a specific target

  info.js gives information about the server given to it via args.

  lib.js is an important library script needed for a lot of the other scripts.

  maxcash.js is a script that will drain all of the servers, I do not reccomend running unless you need money desperately.
    deploys wk.js and hk.js to all servers with a specific target

  min.js is my testing script. feel free to edit it to your needs

  myHNet.js is a script that purchases and upgrades hacknet nodes.

  restore.js is a script to make go.js work again once it stops working, however it may not work all the time, also not currently in use.
    deploys wk.js and gr.js to all servers with a specific target

  self-hack.js is a script that tells a server to hack, grow, and weaken itself. reccommended for later game.

  self-hack-deploy.js deploys self-hack.js to all servers.

  thousand.js is a script you only need to run to get one of the achievements.

  upgrade-server-RESERV.js is an end-game script to keep your money above 100b whilst also upgrading your purchased servers.

  upgrade-server.js is a script to upgrade your purchased servers to better RAM levels.

  




  I would reccomend adding "run factions-toast.js; run myHNet.js; run go.js" to your autoexec scripts in Help -> Options -> System.